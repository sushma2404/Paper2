import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { SearchFormComponent } from './search-form/search-form.component';
import { ProductListComponent } from './product-list/product-list.component';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import { ProductListService } from './product-list.service';
 
const routes: Routes = [
 {path: 'search-form', component: SearchFormComponent},
 {path: 'product-list', component: ProductListComponent}
];
@NgModule({
 declarations: [
 AppComponent,
 SearchFormComponent,
 ProductListComponent
 ],
 imports: [
 BrowserModule,
 AppRoutingModule,
 HttpClientModule,
 FormsModule,
 RouterModule.forRoot(routes)
 ],
 providers: [ProductListService],
 bootstrap: [AppComponent]
})
export class AppModule { }