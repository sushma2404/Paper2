import { Component, OnInit } from '@angular/core';
import { ProductListService } from '../product-list.service';
import { Product } from '../product';
import { ActivatedRoute } from '@angular/router';
 
@Component({
 selector: 'app-product-list',
 templateUrl: './product-list.component.html',
 styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
 uname: string;
 constructor(private service: ProductListService, private route: ActivatedRoute) {
 route.params.subscribe(params => this.uname = params['uname']);
 }
 proList: Product[];
 ngOnInit() {
 this.getAllProducts();
 }
 
 getAllProducts() {
 this.service.getAllProducts().subscribe(data => this.proList = data);
 }
 
}