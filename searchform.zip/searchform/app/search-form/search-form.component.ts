import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductListService } from '../product-list.service';
@Component({
  selector: 'app-search-form',
  templateUrl: './search-form.component.html',
  styleUrls: ['./search-form.component.css']
})
export class SearchFormComponent implements OnInit {
  searchList: Product[];
  searchdetails: Product[];
  constructor(private search: ProductListService) { }

  ngOnInit() {
    this.getAllProducts();
  }
  getAllProducts() {
    this.search.getAllProducts().subscribe(data => this.searchList = data);
  }

  searching(data) {
    let j = 0;
   // this.searchdetails[]=[];
      this.searchdetails = [];
    for (let i = 0; i < this.searchList.length; i++) {
       if (data.value.name === this.searchList[i].name) {
        this.searchdetails[j] = this.searchList[i];

      }
      }
}
}
